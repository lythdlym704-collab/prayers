# المسبحة النبوية

عدّاد للصلاة على النبي ﷺ. شاشة واحدة، يعمل بدون إنترنت، ولا يرسل أي شيء إلى أي خادم.

## محتويات المشروع

| المسار | الوظيفة |
|---|---|
| `www/index.html` | التطبيق كاملاً (الواجهة والمنطق) |
| `www/sw.js` و `www/manifest.webmanifest` | التثبيت كـ PWA والعمل بدون إنترنت |
| `www/icons/` | أيقونات PWA |
| `www/fonts/` | مكان خطوط Amiri و Cairo المضمَّنة |
| `assets/` | أيقونة وشاشة بداية لمتاجر أندرويد وآيفون |
| `capacitor.config.json` و `package.json` | تغليف التطبيق بـ Capacitor |

## الطريق الأخف: PWA

1. ارفع محتوى مجلد `www` إلى أي استضافة HTTPS (GitHub Pages أو Netlify أو Cloudflare Pages).
2. افتح الرابط على الهاتف:
   - أندرويد (Chrome): القائمة ← «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق».
   - آيفون (Safari): زر المشاركة ← «إضافة إلى الشاشة الرئيسية».
3. بعد أول فتح يعمل التطبيق بدون إنترنت.

للتجربة على الحاسوب: `npm run serve`.

## تطبيق للمتاجر: Capacitor

يلزم Node.js، ومعه Android Studio لأندرويد، و Xcode على ماك لآيفون.

```bash
npm install
npm run fonts          # ينسخ الخطوط إلى www/fonts
npx cap add android
npx cap add ios
npm run assets         # يولّد الأيقونات وشاشات البداية من assets/
npm run android        # أو: npm run ios
```

ثم في المشروع الأصلي:

- **الاتجاه العمودي فقط**
  - أندرويد: أضف `android:screenOrientation="portrait"` إلى وسم `<activity>` في `android/app/src/main/AndroidManifest.xml`.
  - آيفون: في Xcode ← Target ← General ← Device Orientation أبقِ Portrait فقط.
- **السمة الداكنة:** ثابتة داخل الصفحة، ولا يوجد وضع فاتح.
- **الاهتزاز:** يستعمل إضافة Haptics داخل Capacitor، و `navigator.vibrate` في المتصفح.

## الخطوط

الصفحة تبحث أولاً عن ثلاثة ملفات في `www/fonts`:

- `Amiri-Regular.woff2`
- `Amiri-Bold.woff2`
- `Cairo-Variable.woff2`

`npm run fonts` ينسخها تلقائياً من حزم fontsource. وإن غابت تُحمَّل الخطوط من Google Fonts ويخزّنها الـ service worker بعد أول فتح. لتطبيق المتاجر يجب أن تكون الملفات موجودة حتى يعمل بدون إنترنت من أول تشغيل.

## التخزين

يُحفظ رقم واحد بالمفتاح `salawat` في `localStorage`. داخل Capacitor تُحفظ نسخة ثانية في Preferences (تخزين النظام) حتى لا يضيع العدد إن أفرغ النظام تخزين المتصفح.

## ملاحظات

- آيفون لا يدعم الاهتزاز في المتصفح أو الـ PWA، فالاهتزاز هناك يعمل في نسخة Capacitor فقط.
- عند تعديل ملفات `www` غيّر قيمة `CACHE` في `sw.js` (مثلاً `misbaha-v2`) ليصل التحديث إلى من ثبّت الـ PWA.
- كلمة «محمد» في الأيقونة مرسومة بخط بديل. إن أردتها بخط Amiri فاستبدل `assets/icon.png` و `www/icons/*.png`.
