// ينسخ خطوط Amiri و Cairo من node_modules إلى www/fonts لتُضمَّن داخل التطبيق.
import { copyFileSync, existsSync, readdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'www', 'fonts');

// نبحث بالاسم لأن أسماء الملفات قد تختلف قليلاً بين إصدارات fontsource
function pick(pkg, patterns) {
  const dir = join(root, 'node_modules', pkg, 'files');
  if (!existsSync(dir)) return null;
  const files = readdirSync(dir);
  for (const p of patterns) {
    const f = files.find((x) => p.test(x));
    if (f) return join(dir, f);
  }
  return null;
}

const jobs = [
  ['Amiri-Regular.woff2', '@fontsource/amiri', [/arabic-400-normal\.woff2$/]],
  ['Amiri-Bold.woff2', '@fontsource/amiri', [/arabic-700-normal\.woff2$/]],
  ['Cairo-Variable.woff2', '@fontsource-variable/cairo', [/arabic-wght-normal\.woff2$/]]
];

let missing = 0;
for (const [name, pkg, patterns] of jobs) {
  const src = pick(pkg, patterns);
  if (!src) { console.warn('لم يُعثر على', name, 'في', pkg); missing++; continue; }
  copyFileSync(src, join(out, name));
  console.log('✓', name);
}
if (missing) console.warn('بعض الخطوط ناقصة: نزّلها يدوياً إلى www/fonts (انظر README).');
