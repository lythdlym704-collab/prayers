/* المسبحة النبوية — service worker: كل شيء من الذاكرة المخبّأة أولاً */
const CACHE = 'misbaha-v1';
const CORE = [
  './',
  'index.html',
  'manifest.webmanifest',
  'fonts/fonts.css',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png',
  'icons/apple-touch-icon.png'
];
const FONT_FILES = [
  'fonts/Amiri-Regular.woff2',
  'fonts/Amiri-Bold.woff2',
  'fonts/Cairo-Variable.woff2'
];
const GOOGLE_CSS =
  'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@400;600;700&display=swap';

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    await c.addAll(CORE);
    // اختيارية: لا يفشل التثبيت إن غابت
    await Promise.allSettled(FONT_FILES.map((u) => c.add(u)));
    await Promise.allSettled([c.add(new Request(GOOGLE_CSS, { mode: 'cors' }))]);
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const isFont = url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (url.origin !== self.location.origin && !isFont) return;

  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    const hit = await c.match(req, { ignoreSearch: url.origin === self.location.origin });
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && (res.ok || res.type === 'opaque')) c.put(req, res.clone());
      return res;
    } catch (err) {
      if (req.mode === 'navigate') return (await c.match('index.html')) || Response.error();
      return Response.error();
    }
  })());
});
